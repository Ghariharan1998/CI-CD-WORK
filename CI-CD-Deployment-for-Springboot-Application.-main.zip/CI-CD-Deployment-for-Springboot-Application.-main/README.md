# CI-CD-Deployment-for-Springboot-Application.
CI/CD Deployment for Springboot Application. 
[ScreenShot.docx](https://github.com/omkaroc27/CI-CD-Deployment-for-Springboot-Application./files/7331924/ScreenShot.docx)
